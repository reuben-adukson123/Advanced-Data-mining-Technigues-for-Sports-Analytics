import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load the dataset
data = pd.read_csv(r"C:\Users\user\Desktop\JIDE\itsrugby_players.csv")

# Display the first few rows of the dataset to understand its structure
print(data.head())

# Convert 'birthdate' to datetime if needed
data['birthdate'] = pd.to_datetime(data['birthdate'], format='%d/%m/%Y', errors='coerce')

# Replace '0' in non-numeric columns with NaN
data.replace('0', pd.NA, inplace=True)

# Fill missing numeric values with 0 or other appropriate value
data.fillna(0, inplace=True)

# Descriptive statistics to get an overview of the dataset
print(data.describe())

# Correlation matrix to see relationships between numerical variables
corr = data[['min', 'played', 'pen', 'yellow', 'red']].corr()
sns.heatmap(corr, annot=True, cmap='coolwarm')
plt.title('Correlation Matrix')
plt.show()

# Playing time distribution by position
sns.boxplot(x='pos', y='min', data=data)
plt.title('Playing Time Distribution by Position')
plt.show()

# Trends over years (average playing time and games played)
# Filter the data to include only numeric columns before grouping
numeric_columns = ['min', 'played', 'year']
yearly_trends = data.groupby('year')[numeric_columns].mean()
yearly_trends.plot(kind='line', marker='o')
plt.title('Average Playing Time and Games Played Over Years')
plt.show()

# Total penalties by position
sns.barplot(x='pos', y='pen', data=data, estimator=sum)
plt.title('Total Penalties by Position')
plt.show()
